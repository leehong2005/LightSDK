//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SampleFileSearch.rc
//
#define IDC_DIALOG                      101
#define IDC_STATIC                      102
#define IDC_LIST                        103
#define IDC_EDIT                        104
#define IDC_SEARCH                      105
#define IDC_COMBOX                      106
#define IDC_SAMPLEPREVIEWHANDLER        107
#define IDC_CLEAR                       108
#define IDR_MENU_FILE                   129
#define IDC_EDIT1                       1000
#define ID_OPEN_OPENFILELOCATION        32771
#define ID_OPEN_OPENFILE                32772
#define IDS_APP_TITLE                   40005
#define IDI_SMALL                       40006
#define IDI_SAMPLEPREVIEWHANDLER        40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
