/*!
* @file CommonVersion.h
* 
* @brief This file defines the file and product version for all output binary files.
* 
* Copyright (C) 2009, LZT Corporation.
* 
* @author Li Hong
* @date 2011/03/31 12:00
*/

#ifndef _SDKCOMMONVERSION_H_
#define _SDKCOMMONVERSION_H_

#define FILEVERSION_VALUE               0,0,0,9
#define FILEVERSION_DISPLAY_VALUE       "0, 0, 0, 9"

#define PRODUCTVERSION_VALUE            0,0,0,9
#define PRODUCTVERSION_DISPLAY_VALUE    "0,0,0,9"

#endif // _SDKCOMMONVERSION_H_
