/*!
* @file CommonMacro.h 
* 
* @brief This file includes some common macro.
* 
* Copyright (C) 2010, LZT Corporation.
* 
* @author Li Hong
* @date 2011/04/20
*/

#ifdef __cplusplus
#ifndef _SDKCOMMONMACRO_H_
#define _SDKCOMMONMACRO_H_


//////////////////////////////////////////////////////////////////////////
//
// Macros definition section
//
//////////////////////////////////////////////////////////////////////////



// The begin of declaration of namespace.
#ifndef BEGIN_NAMESPACE
#define BEGIN_NAMESPACE(name)       namespace name {
#endif // BEGIN_NAMESPACE


// The end of declaration of namespace.
#ifndef END_NAMESPACE
#define END_NAMESPACE               }
#endif // END_NAMESPACE


// Using the namespace macro.
#ifndef USING_NAMESPACE
#define USING_NAMESPACE(name)       using namespace name;
#endif // USING_NAMESPACE


// The common library namespace.
#define COMMON_NAMESPACE            CommonLib

#define BEGIN_NAMESPACE_COMMON      BEGIN_NAMESPACE(COMMON_NAMESPACE)
#define USING_NAMESPACE_COMMON      USING_NAMESPACE(COMMON_NAMESPACE)
#define BEGIN_NAMESPACE_UI          BEGIN_NAMESPACE(UILib)
#define USING_NAMESPACE_UI          USING_NAMESPACE(UILib)



// This macro is used for COM interface to add the reference count.
// typically used when user want to equal two COM interfaces.
#ifndef SAFE_ADDREF
#define SAFE_ADDREF(p)              \
        {                           \
            if ((p) != NULL)        \
            {                       \
                (p)->AddRef();      \
            }                       \
        }
#endif // SAFE_ADDREF


// Release a COM interface, it is no necessary to check NULL of the interface.
#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)             \
        {                           \
            if ((p) != NULL)        \
            {                       \
                (p)->Release();     \
                (p) = NULL;         \
            }                       \
        }
#endif // SAFE_RELEASE


// Delete the memory allocated with C++ operator new.
#ifndef SAFE_DELETE
#define SAFE_DELETE(p)              \
        {                           \
            if ((p) != NULL)        \
            {                       \
                delete (p);         \
                (p) = NULL;         \
            }                       \
        }
#endif // SAFE_DELETE


// Delete the memory array allocated with C++ operator new[].
#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p)        \
        {                           \
            if ((p) != NULL)        \
            {                       \
                delete [] (p);      \
                (p) = NULL;         \
            }                       \
        }
#endif // SAFE_DELETE_ARRAY


// Used to check a handle is valid or invalid, usually the handle is file handle.
#ifndef ISVALIDHANDLE
#define ISVALIDHANDLE(h)        ( (h) != NULL && (h) != INVALID_HANDLE_VALUE )
#endif // ISVALIDHANDLE


// Safe close the handle to a file handle. This macro call ::CloseHandle function.
#ifndef SAFE_CLOSE_HANDLE
#define SAFE_CLOSE_HANDLE(h)                    \
        {                                       \
            if (ISVALIDHANDLE((h)))             \
            {                                   \
                ::CloseHandle((h));             \
                (h) = NULL;                     \
            }                                   \
        }
#endif // SAFE_CLOSE_HANDLE


// This macro call ::DeleteObject function to delete GDI object, such as HBITMAP.
#ifndef SAFE_DELETE_OBJECT
#define SAFE_DELETE_OBJECT(h)                   \
        {                                       \
            if (NULL != (h))                    \
            {                                   \
                ::DeleteObject((h));            \
                (h) = NULL;                     \
            }                                   \
        }
#endif // SAFE_DELETE_OBJECT


// The macro call ::DestroyIcon function to destroy an icon from LoadIcon, CreateIcon, ect.
#ifndef SAFE_DELETE_ICON
#define SAFE_DELETE_ICON(h)                     \
        {                                       \
            if (NULL != (h))                    \
            {                                   \
                ::DestroyIcon((h));             \
                (h) = NULL;                     \
            }                                   \
        }
#endif // SAFE_DELETE_ICON


// This macro call ::DeleteDC function to delete the device context from CreateDC, ect.
#ifndef SAFE_DELETE_DC
#define SAFE_DELETE_DC(h)                       \
        {                                       \
            if (NULL != (h))                    \
            {                                   \
                ::DeleteDC((h));                \
                (h) = NULL;                     \
            }                                   \
        }
#endif // SAFE_DELETE_DC


#ifndef FILTER_BITVALUE
#define FILTER_BITVALUE(val, bit, vct)          \
        {                                       \
            if (val & bit)                      \
            {                                   \
                vct.push_back(bit);             \
            }                                   \
        }
#endif // FILTER_BITVALUE


// Convert GDI RECT to D2DRECt.
#ifndef RECT_TO_D2DRECT
#define RECT_TO_D2DRECT(rc)                     \
        {                                       \
            (FLOAT)((rc).left),                 \
            (FLOAT)((rc).top),                  \
            (FLOAT)((rc).right),                \
            (FLOAT)((rc).bottom)                \
        }
#endif // RECT_TO_D2DRECT


// Convert D2DRECT to GDI RECT.
#ifndef D2DRECT_TO_RECT
#define D2DRECT_TO_RECT(rc)                     \
        {                                       \
            (LONG)((rc).left),                  \
            (LONG)((rc).top),                   \
            (LONG)((rc).right),                 \
            (LONG)((rc).bottom)                 \
        }
#endif // D2DRECT_TO_RECT


// Get the HRESULT value from last error.
#ifndef RESULT_FROM_KNOWN_LASTERROR
#define RESULT_FROM_KNOWN_LASTERROR             \
        {                                       \
            const DWORD err = ::GetLastError(); \
            if (ERROR_SUCCESS == err)           \
            {                                   \
                return S_OK;                    \
            }                                   \
            else                                \
            {                                   \
                return HRESULT_FROM_WIN32(err); \
            }                                   \
        }
#endif // RESULT_FROM_KNOWN_LASTERROR


// This macro function calls the C runtime's _beginthreadex function. 
// The C runtime library doesn't want to have any reliance on Windows' data 
// types such as HANDLE. This means that a Windows programmer needs to cast
// values when using _beginthreadex. Since this is terribly inconvenient, 
// I created this macro to perform the casting.
typedef unsigned (__stdcall *PTHREAD_START) (void *);

#ifndef chBEGINTHREADEX
#define chBEGINTHREADEX(psa, cbStackSize, pfnStartAddr, \
   pvParam, dwCreateFlags, pdwThreadId)                 \
      ((HANDLE)_beginthreadex(                          \
         (void *)        (psa),                         \
         (unsigned)      (cbStackSize),                 \
         (PTHREAD_START) (pfnStartAddr),                \
         (void *)        (pvParam),                     \
         (unsigned)      (dwCreateFlags),               \
         (unsigned *)    (pdwThreadId)))
#endif // chBEGINTHREADEX


#ifndef ARRAYSIZE
#define ARRAYSIZE(a)       ( sizeof((a)) / sizeof((a)[0]) )
#endif // ARRAYSIZE


#ifndef GET_RIGHT_VALUE
#define GET_RIGHT_VALUE(val, max, min)    (val > max) ? max : ((val < min) ? min : val)
#endif // GET_RIGHT_VALUE


#ifndef MAX
#define MAX(x, y)           ( ((x) > (y) ) ? (x) : (y) )
#endif // MAX


#ifndef MIN
#define MIN(x, y)           ( ((x) < (y) ) ? (x) : (y) )
#endif // MIN


#ifndef UPCASE
#define UPCASE(c)           ( ((c)>='a' && (c)<='z') ? ((c)-0x20) : (c) )
#endif // UPCASE


#ifndef LOWERCASE
#define LOWERCASE(str)      CharLower(const_cast<TCHAR*>(str.c_str()))
#endif // LOWERCASE


#ifndef UPPERCASE
#define UPPERCASE(str)      CharUpper(const_cast<TCHAR*>(str.c_str()))
#endif // UPPERCASE


#ifndef RECT_HEIGHT
#define RECT_HEIGHT(rc)     ( (rc).bottom - (rc).top )
#endif // RECT_HEIGHT


#ifndef RECT_WIDTH
#define RECT_WIDTH(rc)      ( (rc).right - (rc).left )
#endif // RECT_WIDTH


#endif // _SDKCOMMONMACRO_H_
#endif // __cplusplus



//////////////////////////////////////////////////////////////////////////
//
// END of file
//
//////////////////////////////////////////////////////////////////////////
