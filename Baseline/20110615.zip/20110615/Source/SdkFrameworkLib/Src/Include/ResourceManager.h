#ifdef __cplusplus
#ifndef _RESOURCEMANAGER_H_
#define _RESOURCEMANAGER_H_


class ResourceManager
{
public:

    ResourceManager();

    ~ResourceManager();
};

#endif // _RESOURCEMANAGER_H_
#endif // __cplusplus
