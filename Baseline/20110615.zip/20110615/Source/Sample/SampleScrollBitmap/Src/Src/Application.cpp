
#include "stdafx.h"
#include "SampleScrollBitmap.h"

int APIENTRY _tWinMain(HINSTANCE hInstance,
                       HINSTANCE hPrevInstance,
                       LPTSTR    lpCmdLine,
                       int       nCmdShow)
{
    {
        SampleScrollBitmapWin win;
        if ( win.CreateMyWindow(hInstance, NULL) )
        {
            MSG msg;
            while ( GetMessage(&msg, NULL, 0, 0) )
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
    }
    return 0;
}