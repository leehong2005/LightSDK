//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SampleKnownFolder.rc
//
#define IDC_MYICON                      2
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_SAMPLEKNOWNFOLDE            107
#define IDI_SMALL                       108
#define IDC_SAMPLEPREVIEWHANDLER        109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_KNOWNFOLDER          129
#define IDC_SCROLLBAR_V                 1001
#define IDC_COMBO_FOLDER                1002
#define IDC_BTN_APPLY                   1003
#define IDC_BTN_CLEAR                   1004
#define IDC_STATIC_TEXT                 1005
#define IDC_RADIO_ICON                  1006
#define IDC_RADIO_BITMAP                1007
#define IDC_STATIC_OP                   -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
