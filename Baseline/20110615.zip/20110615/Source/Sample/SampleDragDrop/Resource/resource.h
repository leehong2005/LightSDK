//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SampleDragDrop.rc
//
#define IDC_MYICON                      2
#define IDI_SAMPLEDRAGDROP              107
#define IDI_SMALL                       108
#define IDR_MAINFRAME                   128

#define IDD_DIALOG              129
#define IDC_IMAGE               130
#define IDC_NAME                131
#define IDC_ATTRIBUTES          132
#define IDC_OPEN                133
#define IDC_CLEAR               134
#define IDC_STATIC              135
#define IDC_CUSTOM_DATAOBJECT   136

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
