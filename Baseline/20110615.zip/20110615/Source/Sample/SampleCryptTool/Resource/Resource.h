//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SampleCryptTool.rc
//
#define IDD_SAMPLECRYPTTOOL_DIALOG      102
#define IDS_APP_TITLE                   103
#define IDI_SMALL                       107
#define IDI_SAMPLECRYPTTOOL             108
#define IDI_ERROR_MSG                   109
#define IDC_SAMPLECRYPTTOOL             110
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_CRYPT                129
#define IDD_DIALOG_MSG                  130
#define IDD_DIALOG_PASSWORD             132
#define IDC_BTN_MAINDLG_BROWSER         501
#define IDC_BTN_MAINDLG_ENCRYPT         502
#define IDC_BTN_MAINDLG_CANCEL          503
#define IDC_BTN_ERRORDLG_OK             504
#define IDC_BTN_ERRORDLG_COPY           505
#define IDC_LIST_ERRORDLG_MSG           506
#define IDC_CHECK_NOERROLIST            999
#define IDC_CHECK_REPLAACEFILES         1000
#define IDC_CHECK_DELORIFILES           1001
#define IDC_EDIT_FILES                  1002
#define IDC_EDIT_PWD1                   1003
#define IDC_EDIT2                       1004
#define IDC_EDIT_PWD2                   1004
#define IDC_BTN_SETPWD                  1005
#define IDC_BTN_MAINDLG_DECRYPT         1009
#define IDC_STATIC_TOTALERROR           2002
#define IDC_STATIC_ERRORPWD             2005
#define IDC_STATIC_FILENAME             -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
