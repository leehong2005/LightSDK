/*!
* @file SdkXmlConfigUtil.cpp
* 
* @brief This file defines SdkXmlConfigUtil class used to parse xml files.
* 
* Copyright (C) 2010, LZT Corporation.
* 
* @author Li Hong
* @date 2011/02/11
*/

#include "SdkXmlConfigUtil.h"

USING_NAMESPACE_COMMON

SdkXmlConfigUtil::SdkXmlConfigUtil()
{
}

//////////////////////////////////////////////////////////////////////////

SdkXmlConfigUtil::~SdkXmlConfigUtil()
{
}
