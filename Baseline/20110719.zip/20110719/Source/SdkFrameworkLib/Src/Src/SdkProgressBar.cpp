/*!
* @file ProcessBar.cpp 
* 
* @brief This file defines the class ProcessBar, it's a control for display process.
* 
* Copyright (C) 2011, LZT Corporation.
* 
* @author Li Hong
* @date 2011/06/24
*/

#include "stdafx.h"
#include "SdkProgressBar.h"

USING_NAMESPACE_VIEWS


SdkProgressBar::SdkProgressBar()
{
    SetClassName(CLASSNAME_PROGRESS);
}

//////////////////////////////////////////////////////////////////////////

SdkProgressBar::~SdkProgressBar()
{
}
