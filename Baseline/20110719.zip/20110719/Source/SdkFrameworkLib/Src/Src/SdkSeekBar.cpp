/*!
* @file SdkSeekBar.cpp
* 
* @brief This file defines the header file of the seekBar.
* 
* Copyright (C) 2011, LZT Corporation.
* 
* @author Li Hong
* @date 2011/07/04
*/

#include "stdafx.h"
#include "SdkSeekBar.h"
#include "Resource.h"
#include "SdkResManager.h"
#include "SdkD2DTheme.h"
#include "D2DRectUtility.h"
#include "ISeekBarEventHandler.h"

USING_NAMESPACE_THEME
USING_NAMESPACE_VIEWS

/*!
* @brief The internal data of seek bar.
*/
struct NAMESPACE_VIEWS::SdkSeekBar::_SEEKBAR_INTERNALDATA
{
    BOOL                     m_isInThumbRect;        // Indicates the point is in thumb rectangle.
    FLOAT                    m_fMinRange;            // The minimum range.
    FLOAT                    m_fMaxRange;            // The maximum range.
    FLOAT                    m_fCurPercent;          // The current percent value.
    D2D1_POINT_2F            m_ptPrevPress;          // The point previous pressed.
    D2DBitmap               *m_pThumbBitmap;         // The thumb bitmap.
    D2DBitmap               *m_pTrackBitmap;         // The track bitmap.
    D2DBitmap               *m_pProgressBitmap;      // The progress bitmap.
    ISeekBarEventHandler    *m_pSeekBarEventHandler; // The seek bar callback interface.
};


//////////////////////////////////////////////////////////////////////////

SdkSeekBar::SdkSeekBar()
{
    m_pSeekBarData = new _SEEKBAR_INTERNALDATA();
    ZeroMemory(m_pSeekBarData, sizeof(_SEEKBAR_INTERNALDATA));

    SetClassName(CLASSNAME_SEEKBAR);
    SetMinHeight(15);
    SetMaxHeight(30);
    SetMinWidth(40);
    SetViewSize(150, 15);

    m_pSeekBarData->m_ptPrevPress.x     = 0;
    m_pSeekBarData->m_ptPrevPress.y     = 0;
    m_pSeekBarData->m_fMaxRange         = 100;
    m_pSeekBarData->m_pThumbBitmap      = new D2DBitmap();
    m_pSeekBarData->m_pTrackBitmap      = new D2DBitmap();
    m_pSeekBarData->m_pProgressBitmap   = new D2DBitmap();

    m_pSeekBarData->m_pThumbBitmap->LoadFromHBITMAP(SdkResManager::GetImage(IDB_SEEKBAR_THUMB));
    m_pSeekBarData->m_pTrackBitmap->LoadFromHBITMAP(SdkResManager::GetImage(IDB_SEEKBAR_TRACK));
    m_pSeekBarData->m_pProgressBitmap->LoadFromHBITMAP(SdkResManager::GetImage(IDB_SEEKBAR_PROGRESS));
}

/////////////////////////////////////////////////////////////////////////

SdkSeekBar::~SdkSeekBar()
{
    SAFE_DELETE(m_pSeekBarData->m_pThumbBitmap);
    SAFE_DELETE(m_pSeekBarData->m_pTrackBitmap);
    SAFE_DELETE(m_pSeekBarData->m_pProgressBitmap);

    SAFE_DELETE(m_pSeekBarData);
}

//////////////////////////////////////////////////////////////////////////

void SdkSeekBar::SetPercent(FLOAT fPercent)
{
    if ( fPercent >= 0.0f && fPercent <= 100.0f )
    {
        if ( m_pSeekBarData->m_fCurPercent != fPercent )
        {
            m_pSeekBarData->m_fCurPercent = fPercent;

            OnPercentChanged(fPercent);
            Invalidate();
        }
    }
}

//////////////////////////////////////////////////////////////////////////

void SdkSeekBar::SetRange(FLOAT fMin, FLOAT fMax)
{
    fMin = max(0, fMin);
    fMax = fMin;
}

//////////////////////////////////////////////////////////////////////////

void SdkSeekBar::SetSeekBarEventHandler(ISeekBarEventHandler *pSeekBarEventHandler)
{
    m_pSeekBarData->m_pSeekBarEventHandler = pSeekBarEventHandler;
}

//////////////////////////////////////////////////////////////////////////

FLOAT SdkSeekBar::GetPercent() const
{
    return m_pSeekBarData->m_fCurPercent;
}

//////////////////////////////////////////////////////////////////////////

void SdkSeekBar::GetRange(FLOAT *pMin, FLOAT *pMax) const
{
    if ( NULL != pMin )
    {
        *pMin = m_pSeekBarData->m_fMinRange;
    }

    if ( NULL != pMax )
    {
        *pMax = m_pSeekBarData->m_fMaxRange;
    }
}

//////////////////////////////////////////////////////////////////////////

void SdkSeekBar::SetThumbPos(FLOAT xPos, FLOAT yPos)
{
    D2D1_RECT_F rc = { 0 };
    GetAbsoluteRect(rc);

    xPos -= rc.left;
    FLOAT fPercent = (xPos / GetWidth()) * 100.0f;

    SetPercent(fPercent);
}

//////////////////////////////////////////////////////////////////////////

BOOL SdkSeekBar::IsPtInThumbRect(FLOAT xPos, FLOAT yPos)
{
    D2D1_POINT_2F srcPT = D2D1::Point2F(xPos, yPos);
    D2D1_POINT_2F desPT = ConvertPoint(srcPT, FALSE);

    // Get the current rectangle of thumb.
    D2D1_RECT_F rcThumb = CalcThumbRect();

    if ( D2DRectUtility::PtInD2DRect(rcThumb, desPT) )
    {
        return TRUE;
    }

    return FALSE;
}

//////////////////////////////////////////////////////////////////////////

D2D1_RECT_F SdkSeekBar::CalcThumbRect()
{
    FLOAT thumbW = 15;
    FLOAT thumbH = 15;

    if ( NULL != m_pSeekBarData->m_pThumbBitmap )
    {
        thumbW = (FLOAT)m_pSeekBarData->m_pThumbBitmap->GetWidth();
        thumbH = (FLOAT)m_pSeekBarData->m_pThumbBitmap->GetHeight();
    }

    FLOAT fWidth = (m_pSeekBarData->m_fCurPercent / 100.0f) * (GetWidth() - thumbW);

    D2D1_RECT_F rc = { 0 };
    GetAbsoluteRect(rc);

    rc.left += fWidth;
    rc.right = rc.left + thumbW;
    rc.top += ((GetHeight() - thumbH) / 2);
    rc.bottom = rc.top + thumbH;

    return rc;
}

//////////////////////////////////////////////////////////////////////////

void SdkSeekBar::OnDrawItem(ID2D1RenderTarget *pRenderTarget)
{
    D2D1_RECT_F rc = { 0 };
    GetAbsoluteRect(rc);

    SdkViewElement::OnDrawItem(pRenderTarget);

    const FLOAT thumbW = 15;
    rc.left  += thumbW / 2;
    rc.right -= thumbW / 2;

    SdkD2DTheme *pD2DTheme = SdkD2DTheme::GetD2DThemeInstance();

    // Draw the track bitmap.
    pD2DTheme->OnDrawSeekBar(
        this,
        pRenderTarget,
        m_pSeekBarData->m_pTrackBitmap,
        rc);

    // Draw the progress bitmap.
    if ( m_pSeekBarData->m_fCurPercent > 0.0f )
    {
        // The thumb's size is 15.
        FLOAT fWidth = (m_pSeekBarData->m_fCurPercent / 100.0f) * (GetWidth() - thumbW);
        rc.right = rc.left + fWidth;

        pD2DTheme->OnDrawSeekBar(
            this,
            pRenderTarget,
            m_pSeekBarData->m_pProgressBitmap,
            rc);
    }

    // Draw the thumb bitmap.
    pD2DTheme->OnDrawSeekBarThumb(
        this,
        pRenderTarget,
        m_pSeekBarData->m_pThumbBitmap,
        m_pSeekBarData->m_fCurPercent,
        rc);
}

//////////////////////////////////////////////////////////////////////////

BOOL SdkSeekBar::OnMouseEvent(UINT message, WPARAM wParam, LPARAM lParam)
{
    BOOL handled = TRUE;

    FLOAT xPos = (FLOAT)GET_X_LPARAM(lParam);
    FLOAT yPos = (FLOAT)GET_Y_LPARAM(lParam);
    BOOL isPressed = (VIEW_STATE_PRESSED == (GetState() & VIEW_STATE_PRESSED));

    switch (message)
    {
    case WM_LBUTTONDOWN:
        {
            m_pSeekBarData->m_isInThumbRect = IsPtInThumbRect(xPos, yPos);
            // The the point is not in the thumb rectangle, move thumb to the current position.
            if ( !m_pSeekBarData->m_isInThumbRect )
            {
                SetThumbPos(xPos, yPos);
            }
        }
        break;

    case WM_LBUTTONUP:
        {
            m_pSeekBarData->m_isInThumbRect = FALSE;
        }
        break;

    case WM_MOUSEMOVE:
        {
            // If the mouse left button is press and the cursor is pressed in the thumb rectangle.
            if ( isPressed && m_pSeekBarData->m_isInThumbRect )
            {
                SetThumbPos(xPos, yPos);
            }
        }
        break;

    default:
        handled = FALSE;
        break;
    }

    SdkViewElement::OnMouseEvent(message, wParam, lParam);

    return handled;
}

//////////////////////////////////////////////////////////////////////////

BOOL SdkSeekBar::OnKeyboardEvent(UINT message, WPARAM wParam, LPARAM lParam)
{
    return TRUE;
}

//////////////////////////////////////////////////////////////////////////

void SdkSeekBar::OnPercentChanged(FLOAT fCurPercent)
{
    // Call the callback to notify client that the percent is changed.
    if ( NULL != m_pSeekBarData->m_pSeekBarEventHandler )
    {
        m_pSeekBarData->m_pSeekBarEventHandler->OnPercentChanged(
            this,
            fCurPercent);
    }
}
