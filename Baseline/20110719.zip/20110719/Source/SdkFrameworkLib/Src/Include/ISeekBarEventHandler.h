/*!
* @file ISeekBarEventHandler.h 
* 
* @brief This file defines events interfaces for SdkSeekBar class.
* 
* Copyright (C) 2010, LZT Corporation.
* 
* @author Li Hong
* @date 2011/01/10
*/

#ifdef __cplusplus
#ifndef _ISEEKBARCHANGELISTENER_H_
#define _ISEEKBARCHANGELISTENER_H_

#include "SdkUICommon.h"

BEGIN_NAMESPACE_CALLBACK

/*!
* @brief ISeekBarEventHandler interface.
*/
class ISeekBarEventHandler
{
public: 

    /*!
    * @brief The destructor function.
    */
    virtual ~ISeekBarEventHandler(){};

    /*!
    * @brief The framework calls this method when the percent is changed.
    *
    * @param pSeekBar       [I/ ] The SdkSeekBar whose progress has changed.
    * @param fCurPercent    [I/ ] The current percent.
    */
    virtual void OnPercentChanged(SdkSeekBar *pSeekBar, FLOAT fCurPercent) = 0;
};

END_NAMESPACE_CALLBACK

#endif // _ISEEKBARCHANGELISTENER_H_
#endif //__cplusplus