/*!
* @file ProcessBar.h 
* 
* @brief This file defines the class ProcessBar, it's a control for display process.
* 
* Copyright (C) 2011, LZT Corporation.
* 
* @author Li Hong
* @date 2011/06/24
*/

#ifdef  __cplusplus
#ifndef _SDKPROGRESSBAR_H_
#define _SDKPROGRESSBAR_H_

#include "SdkViewElement.h"

BEGIN_NAMESPACE_VIEWS

/*!
* @brief This file defines the class ProcessBar, it's a control for display process.
*/
class CLASS_DECLSPEC SdkProgressBar : public SdkViewElement
{
public:

    /*!
    * @brief The constructor function.
    */
    SdkProgressBar();

    /*!
    * @brief The destructor function.
    */
    virtual ~SdkProgressBar();
};

END_NAMESPACE_VIEWS

#endif // _SDKPROGRESSBAR_H_
#endif // __cplusplus
