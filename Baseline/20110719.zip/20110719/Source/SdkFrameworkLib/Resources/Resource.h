//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MediaUIFramework.rc
//
#include "SdkCommonVersion.h"

#define IDS_BUTTON_OK                   101
#define IDS_BUTTON_CANCEL               102
#define IDS_BUTTON_ABORT                103
#define IDS_BUTTON_IDRETRY              104
#define IDS_BUTTON_IGNORE               105
#define IDS_BUTTON_YES                  106
#define IDS_BUTTON_NO                   107
#define IDS_BUTTON_CLOSE                108
#define IDS_BUTTON_HELP                 109

#define IDB_BUTTON_BK                   501
#define IDB_BUTTON_BK_F                 502
#define IDB_PNG_DROP_BOX_NORMAL         505
#define IDB_PNG_DROP_BOX_OPEN           506
#define IDB_PNG_DROP_BOX_TOUCH          507
#define IDB_PNG_DROPDOWN_FOCUS          508
#define IDB_PNG_DROPDOWN_BASE           509
#define IDB_PNG_ERROR                   510
#define IDB_PNG_QUESTION                511
#define IDB_PNG_WARNING                 512
#define IDB_PNG_INFORMATION             513
#define IDB_BUTTON_CLOSE_N              514
#define IDB_BUTTON_DIALOG_N             515
#define IDB_BUTTON_DIALOG_T             516
#define IDB_SEEKBAR_BASE                517
#define IDB_BAR_BASELEFT                518
#define IDB_BAR_BASECENTER              519
#define IDB_BAR_BASERIGHT               520
#define IDB_BAR_BASEL                   521
#define IDB_BAR_BASEC                   522
#define IDB_BAR_BASER                   523
#define IDB_PNG_DIALOG                  524
#define IDB_BUTTON_CLOSE_T              525
#define IDB_PNG_DEFAULT_PICTURE         526


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
